import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import Image from "next/image";

export default function CrisisScenesPage() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">Crisis Scenes & Meme Warfare</h1>
        <p className="text-muted-foreground text-lg">
          A detailed explanation of Executive Disorder's crisis event system and social media mechanics
        </p>
        <Separator className="my-4" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Crisis System Overview</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            Executive Disorder features a dynamic crisis system that challenges players with unexpected events requiring immediate and strategic responses. These crisis scenes create high-pressure decision points that can significantly impact the game's trajectory.
          </p>
          <div className="relative rounded-md overflow-hidden h-60 my-4">
            <Image
              src="/assets/c7vhokkt12v-image.png"
              alt="Executive Disorder Crisis Scene"
              fill
              className="object-cover"
            />
          </div>
          <p>
            Crises are designed to test the player's leadership abilities under pressure, forcing difficult choices with incomplete information and multiple competing priorities. How players navigate these moments often defines public perception of their presidency and shapes the narrative direction of their playthrough.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Crisis Categories</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Natural Disasters</h3>
              <p>
                Environmental catastrophes requiring emergency management, resource allocation, and public safety measures.
              </p>
              <ul className="list-disc pl-6">
                <li>Hurricanes and floods</li>
                <li>Earthquakes</li>
                <li>Wildfires</li>
                <li>Extreme weather events</li>
                <li>Pandemic outbreaks</li>
              </ul>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Economic Crises</h3>
              <p>
                Financial emergencies that threaten economic stability and require interventionist policies.
              </p>
              <ul className="list-disc pl-6">
                <li>Market crashes</li>
                <li>Banking collapses</li>
                <li>Currency devaluations</li>
                <li>Trade wars</li>
                <li>Supply chain disruptions</li>
              </ul>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Security Incidents</h3>
              <p>
                Threats to national security requiring intelligence analysis, military readiness, and public safety measures.
              </p>
              <ul className="list-disc pl-6">
                <li>Terrorist attacks</li>
                <li>Cyber security breaches</li>
                <li>Border incursions</li>
                <li>Domestic unrest</li>
                <li>Assassination attempts</li>
              </ul>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Diplomatic Incidents</h3>
              <p>
                International conflicts or diplomatic emergencies requiring careful negotiation and strategic thinking.
              </p>
              <ul className="list-disc pl-6">
                <li>Hostage situations</li>
                <li>International provocations</li>
                <li>Diplomatic scandals</li>
                <li>Treaty violations</li>
                <li>Military standoffs</li>
              </ul>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Political Scandals</h3>
              <p>
                Internal political emergencies threatening administration credibility and requiring damage control.
              </p>
              <ul className="list-disc pl-6">
                <li>Cabinet member misconduct</li>
                <li>Corruption allegations</li>
                <li>Leaked information</li>
                <li>Ethics violations</li>
                <li>Cover-up accusations</li>
              </ul>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Social Crises</h3>
              <p>
                Major societal disruptions requiring leadership, communication, and policy responses.
              </p>
              <ul className="list-disc pl-6">
                <li>Civil unrest</li>
                <li>Culture war flashpoints</li>
                <li>Mass protests</li>
                <li>Social movement confrontations</li>
                <li>Institutional failures</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Crisis Mechanics</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            Executive Disorder implements sophisticated mechanics for crisis management:
          </p>

          <div className="border p-6 rounded-md space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Crisis Triggers</h3>
                <p>
                  Crises can be triggered by multiple factors including random events, metric thresholds, previous decisions, character actions, or scheduled narrative points. The game's AI evaluates numerous factors to determine when and which crises occur.
                </p>
              </div>

              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Escalation System</h3>
                <p>
                  Crises can escalate if not handled effectively, with minor incidents growing into major emergencies that consume more resources and attention. The escalation trajectory depends on player responses and external factors.
                </p>
              </div>

              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Information Management</h3>
                <p>
                  During crises, players must manage incomplete or evolving information. They can invest resources in intelligence gathering, but must often make decisions before having complete data, creating risk-reward dynamics.
                </p>
              </div>

              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Resource Allocation</h3>
                <p>
                  Players must allocate limited resources (staff, budget, attention, political capital) during crises, creating strategic trade-offs. Resources committed to crisis management become unavailable for other priorities.
                </p>
              </div>

              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Crisis Teams</h3>
                <p>
                  Players can form crisis response teams from available characters, with team composition affecting response options and effectiveness. Character traits and relationships influence team performance during crises.
                </p>
              </div>

              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Narrative Branching</h3>
                <p>
                  Crisis responses create significant narrative branches, with consequences reverberating throughout the game world. Some responses permanently close off certain future options while opening others.
                </p>
              </div>
            </div>

            <div className="relative rounded-md overflow-hidden h-60 mt-6">
              <Image
                src="/assets/30jp0eh1pl8-image.png"
                alt="Crisis Response System Diagram"
                fill
                className="object-contain"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Meme Warfare System</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            Executive Disorder features an innovative "Meme Warfare" system that simulates social media dynamics and public narrative battles:
          </p>

          <div className="relative rounded-md overflow-hidden h-60 my-4">
            <Image
              src="/assets/bgwl6gykffh-image.png"
              alt="Meme Warfare Interface"
              fill
              className="object-cover"
            />
          </div>

          <p>
            The Meme Warfare system represents how modern political battles are increasingly fought through viral content, social media narratives, and information campaigns. Players must engage with this system to shape public perception, counter opposition narratives, and build support for their agenda.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
            <div className="space-y-3">
              <h3 className="text-lg font-semibold">MemeSpace Platform</h3>
              <p>
                The game features a fictional social media platform called "MemeSpace" where players monitor public sentiment, track trending topics, and deploy strategic communications.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Narrative Battles</h3>
              <p>
                Key events and policies become battlegrounds for competing narratives. Players must craft effective counter-narratives to opposition framing or promote their preferred interpretation of events.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Meme Creation</h3>
              <p>
                Players can craft memes by combining templates, topics, and messaging approaches. Effective memes balance humor, relevance, and strategic messaging to maximize impact.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Viral Mechanics</h3>
              <p>
                Memes have dynamic viral potential based on multiple factors including timing, relevance, crafting quality, and alignment with audience values. Successful memes can reshape public perception on issues.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Digital Campaign Teams</h3>
              <p>
                Players can build and direct digital campaign teams with different specialties (rapid response, long-form content, visual design, demographic targeting) to enhance meme effectiveness.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Hashtag Campaigns</h3>
              <p>
                Strategic use of hashtag campaigns can amplify messages, coordinate supporters, and shape media coverage of issues. Players must choose when and how to deploy these campaign tools.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Meme Warfare Mechanics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <p>
              The Meme Warfare system operates through several sophisticated mechanics:
            </p>

            <div className="border p-6 rounded-md space-y-6">
              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Meme Construction</h3>
                <p>
                  Players construct memes through a component-based system:
                </p>
                <ul className="list-disc pl-6 grid grid-cols-1 md:grid-cols-2 gap-2">
                  <li><strong>Template Selection:</strong> Choosing from various visual formats</li>
                  <li><strong>Messaging Strategy:</strong> Emotional tone and approach</li>
                  <li><strong>Target Audience:</strong> Demographic and psychographic targeting</li>
                  <li><strong>Issue Framing:</strong> How the issue is contextualized</li>
                  <li><strong>Visual Elements:</strong> Graphics, colors, and imagery</li>
                  <li><strong>Call to Action:</strong> What response is sought</li>
                </ul>
              </div>

              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Virality Factors</h3>
                <p>
                  Meme effectiveness is determined by multiple factors:
                </p>
                <ul className="list-disc pl-6 grid grid-cols-1 md:grid-cols-2 gap-2">
                  <li><strong>Relevance:</strong> Timeliness and connection to current events</li>
                  <li><strong>Resonance:</strong> Alignment with audience values and concerns</li>
                  <li><strong>Simplicity:</strong> Clarity and memorability of the message</li>
                  <li><strong>Emotional Impact:</strong> Strength of emotional response triggered</li>
                  <li><strong>Novelty:</strong> Originality and surprise factor</li>
                  <li><strong>Production Quality:</strong> Visual appeal and professionalism</li>
                </ul>
              </div>

              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Deployment Strategy</h3>
                <p>
                  Players must make strategic decisions about meme deployment:
                </p>
                <ul className="list-disc pl-6 grid grid-cols-1 md:grid-cols-2 gap-2">
                  <li><strong>Timing:</strong> When to release content for maximum impact</li>
                  <li><strong>Platform Selection:</strong> Which social channels to prioritize</li>
                  <li><strong>Amplification Strategy:</strong> Using influencers or paid promotion</li>
                  <li><strong>Coordination:</strong> Aligning with offline messaging</li>
                  <li><strong>Frequency:</strong> How often to deploy on a given topic</li>
                  <li><strong>Sequencing:</strong> Order and rhythm of related content</li>
                </ul>
              </div>

              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Narrative Control Systems</h3>
                <p>
                  The game tracks narrative dominance across different issues:
                </p>
                <ul className="list-disc pl-6">
                  <li><strong>Narrative Control Meter:</strong> Measuring which side's framing is dominant on an issue</li>
                  <li><strong>Narrative Momentum:</strong> Rate of change in narrative control</li>
                  <li><strong>Framing Persistence:</strong> How long narrative control lasts without reinforcement</li>
                  <li><strong>Topic Salience:</strong> How much the public cares about a given issue</li>
                  <li><strong>Media Amplification:</strong> Whether mainstream media adopts social media framing</li>
                </ul>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Integration of Crisis and Meme Systems</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            A key innovation in Executive Disorder is the tight integration between the crisis management and meme warfare systems:
          </p>

          <ul className="list-disc pl-6 space-y-3">
            <li>
              <strong>Crisis Narrative Battles:</strong> During crises, opposition forces deploy memes to shape public perception of events. Players must balance immediate crisis response with managing the public narrative.
            </li>
            <li>
              <strong>Perception vs. Reality:</strong> The game creates tension between actual crisis performance (measured in objective metrics) and perceived performance (shaped by narrative control), reflecting real-world political dynamics.
            </li>
            <li>
              <strong>Information Cascades:</strong> Viral memes during crises can trigger information cascades that affect public behavior, potentially helping or hindering crisis management efforts.
            </li>
            <li>
              <strong>Media Cycle Management:</strong> Players must manage the evolving media cycle during crises, with different phases requiring different communication strategies (initial response, ongoing updates, aftermath framing).
            </li>
            <li>
              <strong>Opposition Exploits:</strong> Political rivals actively exploit crises through meme warfare, attempting to define events in ways that damage the player's administration.
            </li>
            <li>
              <strong>Crisis-Triggered Memes:</strong> Certain player actions during crises can spontaneously generate viral memes (both positive and negative) based on their memorability or emotional impact.
            </li>
          </ul>

          <div className="border-l-4 border-primary p-4 bg-muted/50 mt-4">
            <h3 className="text-lg font-semibold mb-2">Strategic Considerations</h3>
            <p>
              The integration of crisis management and meme warfare creates complex strategic considerations:
            </p>
            <ul className="list-disc pl-6 mt-2">
              <li>When to prioritize actual crisis response vs. perception management</li>
              <li>How to leverage successful crisis management for narrative advantage</li>
              <li>When to accept short-term narrative losses for better crisis outcomes</li>
              <li>How to prepare for predictable narrative attacks during different crisis types</li>
              <li>Ways to inoculate public opinion against misleading opposition framing</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Advanced Meme Warfare Techniques</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            As players progress, they unlock advanced meme warfare capabilities:
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Rapid Response Teams</h3>
              <p>
                Specialized staff units that can quickly respond to emerging narratives with counter-memes before they go viral.
              </p>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Narrative Forecasting</h3>
              <p>
                Predictive tools that anticipate potential negative narratives before they emerge, allowing preemptive framing.
              </p>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Memetic A/B Testing</h3>
              <p>
                Testing multiple meme versions with small audiences before full deployment to optimize effectiveness.
              </p>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Counter-Narrative Campaigns</h3>
              <p>
                Coordinated multi-meme campaigns designed to systematically dismantle opposition narratives on key issues.
              </p>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Influencer Networks</h3>
              <p>
                Building and activating networks of digital influencers who can amplify administration messaging.
              </p>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Algorithmic Optimization</h3>
              <p>
                Advanced techniques to work with (or around) social media algorithms to maximize content reach and engagement.
              </p>
            </div>
          </div>

          <p className="mt-4">
            These systems combine to create a rich, strategic layer that simulates the modern battlefield of political communication, challenging players to master both crisis management and narrative control to succeed in Executive Disorder.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
