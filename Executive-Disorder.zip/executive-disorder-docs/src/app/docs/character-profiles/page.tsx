import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import Image from "next/image";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export default function CharacterProfilesPage() {
  const characterTypes = [
    {
      id: "cabinet",
      type: "Cabinet Members",
      description: "Key advisors and department heads who form the President's inner circle",
      traits: ["Loyalty", "Competence", "Political Leaning", "Public Perception", "Special Abilities"]
    },
    {
      id: "rivals",
      type: "Political Rivals",
      description: "Opposition leaders and competitors who challenge the President's agenda",
      traits: ["Hostility Level", "Public Support", "Political Strength", "Special Tactics", "Vulnerability"]
    },
    {
      id: "foreign",
      type: "Foreign Leaders",
      description: "Heads of state from other nations with whom diplomatic relations must be maintained",
      traits: ["Relationship Status", "Trade Importance", "Military Power", "Diplomatic Style", "Strategic Interests"]
    },
    {
      id: "media",
      type: "Media Figures",
      description: "Journalists, talk show hosts, and influencers who shape public opinion",
      traits: ["Political Bias", "Audience Size", "Investigative Ability", "Interview Style", "Narrative Preference"]
    },
    {
      id: "interest",
      type: "Special Interest Leaders",
      description: "Representatives of various lobbying groups and constituencies",
      traits: ["Resource Control", "Voter Influence", "Policy Demands", "Support Conditions", "Pressure Tactics"]
    }
  ];

  const characterSamples = [
    {
      id: "morgan",
      name: "Secretary James Morgan",
      role: "Secretary of Defense",
      type: "Cabinet Member",
      traits: "Centrist, highly competent but with low loyalty. Former military general with strong connections to defense contractors.",
      strategy: "Provide regular military briefings to maintain trust. Monitor for signs of disloyalty during defense budget negotiations."
    },
    {
      id: "hayes",
      name: "Senator Eleanor Hayes",
      role: "Opposition Party Leader",
      type: "Political Rival",
      traits: "Charismatic, media-savvy with strong grassroots support. Particularly effective at exploiting scandals.",
      strategy: "Counter her narratives quickly with meme warfare. Avoid direct confrontation which feeds into her 'outsider vs. establishment' narrative."
    },
    {
      id: "wei",
      name: "Premier Zhao Wei",
      role: "Foreign Leader",
      type: "Foreign Leader",
      traits: "Calculating and strategic with long-term geopolitical goals. Controls significant trade relationships.",
      strategy: "Balance firm diplomatic stances with economic cooperation. Use formal diplomatic channels rather than public statements."
    },
    {
      id: "blake",
      name: "Victoria Blake",
      role: "Cable News Host",
      type: "Media Figure",
      traits: "Conservative leaning with massive viewership. Known for aggressive interviews and opinion segments.",
      strategy: "Prepare thoroughly for interviews. Engage selectively via social media. Counter narratives through surrogates rather than direct conflict."
    }
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">Character Profiles & Strategies</h1>
        <p className="text-muted-foreground text-lg">
          An analysis of the key characters in Executive Disorder and effective strategies for interacting with them
        </p>
        <Separator className="my-4" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Character System Overview</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            Executive Disorder features a rich cast of characters with unique personalities, agendas, and relationship dynamics. Each character has individual traits that affect how they respond to the player's decisions and actions.
          </p>
          <div className="relative rounded-md overflow-hidden h-60 my-4">
            <Image
              src="/assets/8im1kg1oxqk-image.png"
              alt="Character Relationship Network"
              fill
              className="object-cover"
            />
          </div>
          <p>
            The character system is designed to create a complex political ecosystem where relationship management is crucial for success. Characters remember past interactions, form alliances and rivalries, and can either help or hinder the player's agenda based on their relationship status.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Character Types</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            The game features several categories of characters, each with their own role in the political landscape:
          </p>

          <div className="space-y-6 mt-4">
            {characterTypes.map((charType) => (
              <div key={charType.id} className="border p-4 rounded-md">
                <h3 className="text-lg font-semibold mb-2">{charType.type}</h3>
                <p className="mb-3">{charType.description}</p>
                <h4 className="text-sm font-medium text-muted-foreground mb-2">Key Traits:</h4>
                <ul className="list-disc pl-6">
                  {charType.traits.map((trait) => (
                    <li key={`${charType.id}-${trait}`}>{trait}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Relationship Mechanics</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">
            Character relationships in Executive Disorder are governed by several key mechanics:
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Trust & Loyalty System</h3>
              <p>
                Each character has a trust meter that reflects their loyalty to the player. This is affected by decisions, private meetings, public statements, and policy choices that align with their interests.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Favor Exchange</h3>
              <p>
                Characters can request favors from the player and provide favors in return. This creates a political economy of exchanges that can be leveraged for strategic advantage.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Personality Traits</h3>
              <p>
                Each character has unique personality traits that influence how they react to different approaches. Some respond better to direct confrontation while others prefer diplomatic approaches.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Network Effects</h3>
              <p>
                Characters have relationships with each other that the player can influence. A character's attitude toward the player can be affected by how the player treats their allies and enemies.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Public vs. Private Interactions</h3>
              <p>
                How the player interacts with a character in public versus private settings can create complex dynamics, with some characters expecting different behaviors in different contexts.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Crisis Response</h3>
              <p>
                How characters react during crisis events is influenced by their relationship with the player, creating high-stakes situations where relationship management becomes crucial.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Example Characters & Strategies</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">
            Below are some examples of characters from the game and effective strategies for managing relationships with them:
          </p>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Key Traits</TableHead>
                <TableHead>Recommended Strategy</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {characterSamples.map((character) => (
                <TableRow key={character.id}>
                  <TableCell className="font-medium">{character.name}</TableCell>
                  <TableCell>{character.role}</TableCell>
                  <TableCell>{character.type}</TableCell>
                  <TableCell>{character.traits}</TableCell>
                  <TableCell>{character.strategy}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Strategic Approaches</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            Players can adopt various strategic approaches to character management:
          </p>
          <ul className="list-disc pl-6 space-y-2">
            <li>
              <strong>Loyalty-Focused:</strong> Prioritize building a loyal inner circle at the expense of broader coalition building
            </li>
            <li>
              <strong>Coalition Builder:</strong> Maintain moderate relationships with a wide range of characters across the political spectrum
            </li>
            <li>
              <strong>Divide and Conquer:</strong> Exploit rivalries between characters to maintain leverage
            </li>
            <li>
              <strong>Public vs. Private:</strong> Maintain different public and private personas to maximize strategic flexibility
            </li>
            <li>
              <strong>Media Management:</strong> Focus on relationships with media figures to shape public narrative
            </li>
          </ul>
          <p className="mt-4">
            The most successful players adapt their character management strategy based on the specific challenges they face and the unique personality traits of key characters in their game world.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
