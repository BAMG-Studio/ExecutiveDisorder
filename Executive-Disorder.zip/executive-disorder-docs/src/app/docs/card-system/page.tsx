import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import Image from "next/image";

export default function CardSystemPage() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">Card System & Decision Mechanics</h1>
        <p className="text-muted-foreground text-lg">
          A detailed overview of Executive Disorder's card-based decision system and mechanics
        </p>
        <Separator className="my-4" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Card System Overview</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            Executive Disorder's core gameplay centers around a sophisticated card-based decision system. Each card represents a political issue, event, or decision point that the player must address as President. The card system creates a dynamic and responsive gameplay experience where choices have both immediate and long-term consequences.
          </p>
          <div className="relative rounded-md overflow-hidden h-60 my-4">
            <Image
              src="/assets/c7vhokkt12v-image.png"
              alt="Executive Disorder Card System"
              fill
              className="object-cover"
            />
          </div>
          <p>
            Cards are presented to the player through various mechanisms including the daily briefing, crisis events, scheduled policy meetings, and character interactions. Each card challenges the player to make strategic decisions that balance multiple competing factors.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Card Types</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Policy Cards</h3>
              <p>
                Represent major policy decisions that affect multiple game metrics and stakeholders. These often involve complex trade-offs and can trigger future events.
              </p>
              <ul className="list-disc pl-6">
                <li>Tax policy reforms</li>
                <li>Healthcare initiatives</li>
                <li>Infrastructure projects</li>
                <li>Military spending decisions</li>
                <li>Environmental regulations</li>
              </ul>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Crisis Cards</h3>
              <p>
                Unexpected emergencies that demand immediate attention and often force difficult choices under time pressure.
              </p>
              <ul className="list-disc pl-6">
                <li>Natural disasters</li>
                <li>Economic crashes</li>
                <li>Security threats</li>
                <li>Public health emergencies</li>
                <li>International conflicts</li>
              </ul>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Character Cards</h3>
              <p>
                Represent interactions with key characters who may request meetings, make demands, offer deals, or present challenges.
              </p>
              <ul className="list-disc pl-6">
                <li>Cabinet member recommendations</li>
                <li>Opposition party negotiations</li>
                <li>Foreign leader summits</li>
                <li>Media interview requests</li>
                <li>Special interest group lobbying</li>
              </ul>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Opportunity Cards</h3>
              <p>
                Present potential advantages but may come with risks or hidden costs that must be evaluated.
              </p>
              <ul className="list-disc pl-6">
                <li>Strategic partnerships</li>
                <li>Economic investments</li>
                <li>Political appointments</li>
                <li>Media opportunities</li>
                <li>Special projects</li>
              </ul>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Social Media Cards</h3>
              <p>
                Represent viral social media trends, memes, or public discussions that require strategic responses.
              </p>
              <ul className="list-disc pl-6">
                <li>Trending hashtags</li>
                <li>Viral misinformation</li>
                <li>Public opinion waves</li>
                <li>Online activism campaigns</li>
                <li>Meme-based attacks</li>
              </ul>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Legacy Cards</h3>
              <p>
                Long-term projects or initiatives that develop over time and can define the player's presidency if successfully managed.
              </p>
              <ul className="list-disc pl-6">
                <li>Major infrastructure initiatives</li>
                <li>Constitutional amendments</li>
                <li>Historic diplomatic treaties</li>
                <li>Transformative social programs</li>
                <li>Revolutionary technological investments</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Card Anatomy</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            Each card in Executive Disorder contains several key components that provide context and guide decision-making:
          </p>

          <div className="border p-6 rounded-md space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Title & Category</h3>
                <p>
                  Each card has a descriptive title and belongs to a specific category (policy, crisis, character, etc.) that helps players understand its nature.
                </p>
              </div>

              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Situation Description</h3>
                <p>
                  A narrative description of the issue, event, or situation that provides context and background information.
                </p>
              </div>

              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Decision Options</h3>
                <p>
                  Multiple response options that represent different approaches to handling the situation, each with its own set of potential consequences.
                </p>
              </div>

              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Stakeholder Information</h3>
                <p>
                  Details about which characters, groups, or factions have a stake in the decision and how they might react to different choices.
                </p>
              </div>

              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Urgency Indicator</h3>
                <p>
                  Visual indicator of how quickly the player must respond, with some cards requiring immediate decisions while others allow for more deliberation.
                </p>
              </div>

              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Resource Requirements</h3>
                <p>
                  Some options may require specific resources like political capital, budget allocations, or staff time to implement effectively.
                </p>
              </div>
            </div>

            <div className="relative rounded-md overflow-hidden h-60 mt-6">
              <Image
                src="/assets/30jp0eh1pl8-image.png"
                alt="Card Anatomy Diagram"
                fill
                className="object-contain"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Decision Mechanics</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            When presented with a card, players must navigate a sophisticated decision system:
          </p>

          <ul className="list-disc pl-6 space-y-3">
            <li>
              <strong>Multiple Choice Options:</strong> Most cards present 3-5 distinct response options, each representing a different strategic approach.
            </li>
            <li>
              <strong>Custom Response Crafting:</strong> For some cards, players can craft custom responses by combining different elements or emphasizing specific aspects.
            </li>
            <li>
              <strong>Timing Considerations:</strong> The timing of decisions can affect outcomes, with some cards having deadlines or shifting consequences based on when decisions are made.
            </li>
            <li>
              <strong>Delegation Options:</strong> Players can sometimes delegate decisions to cabinet members or advisors, which shifts responsibility but reduces direct control.
            </li>
            <li>
              <strong>Information Gathering:</strong> Before making some decisions, players can invest resources in gathering additional information to better understand potential consequences.
            </li>
            <li>
              <strong>Consultation Mechanics:</strong> Players can consult with advisors or stakeholders before making decisions, gaining insights but potentially creating expectations.
            </li>
            <li>
              <strong>Decision Deferral:</strong> Some non-urgent cards can be deferred, but this may lead to escalation or changed circumstances when they reappear.
            </li>
          </ul>

          <div className="border-l-4 border-primary p-4 bg-muted/50 mt-4">
            <h3 className="text-lg font-semibold mb-2">Decision Impact Chain</h3>
            <p>
              A key feature of Executive Disorder's decision system is the complex chain of consequences that can result from a single choice. Decisions create cascading effects across multiple game systems:
            </p>
            <ol className="list-decimal pl-6 mt-2 space-y-1">
              <li>Initial decision creates immediate metric changes</li>
              <li>Character relationships update based on the decision</li>
              <li>Media coverage and public opinion shift in response</li>
              <li>New cards may be triggered as direct consequences</li>
              <li>Long-term effects unfold over time through the game state</li>
              <li>Memory system ensures past decisions influence future options</li>
            </ol>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Card Delivery System</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            Cards are delivered to the player through several sophisticated systems:
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Daily Briefing</h3>
              <p>
                Each in-game day begins with a briefing session where the most pressing issues are presented as cards for the player to address.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Scheduled Events</h3>
              <p>
                Certain cards appear at predetermined points in the game calendar, such as budget negotiations, election campaigns, or international summits.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Crisis Interruptions</h3>
              <p>
                Urgent crisis cards can interrupt normal gameplay, requiring immediate attention regardless of the player's current activities.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Character Interactions</h3>
              <p>
                Meeting with characters or responding to their communications can trigger specific cards related to their concerns or agendas.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Consequence Chains</h3>
              <p>
                Previous decisions can trigger follow-up cards that represent the consequences or developments stemming from earlier choices.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Dynamic Generation</h3>
              <p>
                The game's AI can dynamically generate cards based on the current game state, player's governing style, and emerging narrative threads.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Card Deck Management</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            Advanced players can strategically influence the card deck through various mechanics:
          </p>

          <ul className="list-disc pl-6 space-y-2">
            <li>
              <strong>Agenda Setting:</strong> Prioritizing certain policy areas increases the frequency of related cards.
            </li>
            <li>
              <strong>Staff Assignments:</strong> Assigning staff to specific issues can preemptively address potential problems before they become cards.
            </li>
            <li>
              <strong>Proactive Initiatives:</strong> Taking initiative on certain issues can replace reactive crisis cards with more controllable policy cards.
            </li>
            <li>
              <strong>Relationship Cultivation:</strong> Building strong relationships with key characters can transform potentially negative cards into opportunities.
            </li>
            <li>
              <strong>Media Narrative Control:</strong> Shaping public discourse through the meme system can influence which social media cards appear.
            </li>
          </ul>

          <p className="mt-4">
            This strategic depth allows players to shape their gameplay experience and adapt their approach based on their preferred governing style and the specific challenges they face during their presidency.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
