import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import Image from "next/image";

export default function GameplayMetricsPage() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">Gameplay Metrics & Decision Impact System</h1>
        <p className="text-muted-foreground text-lg">
          A detailed analysis of how Executive Disorder tracks and responds to player decisions
        </p>
        <Separator className="my-4" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Metrics Overview</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            Executive Disorder features a sophisticated metrics system that tracks various aspects of the player's presidency. These metrics are constantly updated based on player decisions and shape both the gameplay experience and available options.
          </p>
          <div className="relative rounded-md overflow-hidden h-60 my-4">
            <Image
              src="/assets/l2l1bc8g0p7-image.png"
              alt="Executive Disorder Metrics Dashboard"
              fill
              className="object-cover"
            />
          </div>
          <p>
            The game's metrics system serves multiple purposes: providing feedback on how player decisions are affecting the game world, creating gameplay challenges through balancing requirements, and driving narrative developments based on the player's governing style.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Core Metrics Categories</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Approval Ratings</h3>
              <p>
                Measures public support across different demographic groups and overall population. Affects ability to implement policies and electoral prospects.
              </p>
              <ul className="list-disc pl-6">
                <li>Overall approval</li>
                <li>Demographic-specific approval</li>
                <li>Regional approval</li>
                <li>Issue-specific approval</li>
                <li>Trend direction (rising/falling)</li>
              </ul>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Political Capital</h3>
              <p>
                Represents political influence and ability to push through agenda items. Spent when implementing policies or navigating crises.
              </p>
              <ul className="list-disc pl-6">
                <li>Current political capital value</li>
                <li>Generation rate</li>
                <li>Expenditure efficiency</li>
                <li>Sources of capital</li>
                <li>Capital reserve margins</li>
              </ul>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Economic Indicators</h3>
              <p>
                Track the health and direction of the national economy, affecting many other gameplay systems.
              </p>
              <ul className="list-disc pl-6">
                <li>GDP growth rate</li>
                <li>Unemployment rate</li>
                <li>Inflation</li>
                <li>Stock market performance</li>
                <li>Budget deficit/surplus</li>
                <li>Economic sentiment index</li>
              </ul>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Social Welfare</h3>
              <p>
                Measures quality of life for citizens across various dimensions of social wellbeing.
              </p>
              <ul className="list-disc pl-6">
                <li>Healthcare access</li>
                <li>Education quality</li>
                <li>Income inequality</li>
                <li>Housing affordability</li>
                <li>Social safety net strength</li>
              </ul>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">National Security</h3>
              <p>
                Tracks safety, defense readiness, and security concerns both domestic and international.
              </p>
              <ul className="list-disc pl-6">
                <li>Military readiness</li>
                <li>Domestic crime rates</li>
                <li>Border security status</li>
                <li>Terrorism threat level</li>
                <li>Cyber security status</li>
              </ul>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Environmental Health</h3>
              <p>
                Measures environmental conditions and sustainability of resource management.
              </p>
              <ul className="list-disc pl-6">
                <li>Pollution levels</li>
                <li>Climate stability</li>
                <li>Natural resource management</li>
                <li>Renewable energy adoption</li>
                <li>Conservation status</li>
              </ul>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">International Relations</h3>
              <p>
                Tracks relationships with foreign powers and standing in the global community.
              </p>
              <ul className="list-disc pl-6">
                <li>Diplomatic standing with key nations</li>
                <li>Trade relationship health</li>
                <li>Alliance strength</li>
                <li>International reputation</li>
                <li>Soft power influence</li>
              </ul>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Media Sentiment</h3>
              <p>
                Measures how media outlets portray the administration and their narrative framing.
              </p>
              <ul className="list-disc pl-6">
                <li>Mainstream media tone</li>
                <li>Social media sentiment</li>
                <li>Media penetration</li>
                <li>Narrative control</li>
                <li>Meme propagation metrics</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Decision Impact System</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            At the heart of Executive Disorder is a sophisticated decision impact system that tracks how player choices affect the game state:
          </p>

          <div className="border p-6 rounded-md space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Multi-Dimensional Impact</h3>
                <p>
                  Each decision can affect multiple metrics simultaneously, often creating trade-offs. For example, increasing military spending might boost national security but decrease economic health and political approval from certain groups.
                </p>
              </div>

              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Time-Based Effects</h3>
                <p>
                  Decisions can have both immediate and delayed consequences. Some effects manifest immediately while others unfold over time or trigger at specific future points, creating a complex temporal dimension to decision-making.
                </p>
              </div>

              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Contextual Impact Variation</h3>
                <p>
                  The same decision made in different contexts can have significantly different outcomes. The impact of choices depends on the current game state, previous decisions, character relationships, and external factors.
                </p>
              </div>

              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Chain Reactions</h3>
                <p>
                  Decisions can trigger cascading effects across multiple systems, creating chain reactions of consequences that ripple through the game world and potentially return as future challenges or opportunities.
                </p>
              </div>
            </div>

            <div className="relative rounded-md overflow-hidden h-60 my-4">
              <Image
                src="/assets/l2l1bc8g0p7-image.png"
                alt="Decision Impact Visualization"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Decision Tracking & Memory</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            Executive Disorder implements a sophisticated decision tracking system:
          </p>

          <ul className="list-disc pl-6 space-y-3">
            <li>
              <strong>Decision History:</strong> The game maintains a comprehensive record of all player decisions, including context, options chosen, and immediate outcomes.
            </li>
            <li>
              <strong>Pattern Recognition:</strong> The system identifies patterns in decision-making, such as consistently favoring certain demographics, policy areas, or approaches to problems.
            </li>
            <li>
              <strong>Consistency Tracking:</strong> The game monitors consistency between related decisions, with inconsistency potentially damaging credibility but strategic inconsistency sometimes being advantageous.
            </li>
            <li>
              <strong>Character Memory:</strong> NPCs remember how the player has treated them and their interests in past interactions, affecting their future behavior and responsiveness.
            </li>
            <li>
              <strong>Media Callback:</strong> Media outlets may reference past decisions when reporting on current events, especially when there are contradictions or notable patterns.
            </li>
            <li>
              <strong>Cumulative Effects:</strong> Repeated similar decisions can have compounding effects beyond their individual impact, representing momentum in particular directions.
            </li>
            <li>
              <strong>Governing Style Profiling:</strong> Based on decision patterns, the game characterizes the player's governing style along multiple dimensions (e.g., authoritarian vs. democratic, progressive vs. conservative).
            </li>
          </ul>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Decision Value System</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">
            The game implements a sophisticated system for valuing and weighing different decisions:
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Decision Magnitude</h3>
              <p>
                Decisions are categorized by their scope and significance, from minor administrative choices to major policy initiatives and critical crisis responses.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Resource Investment</h3>
              <p>
                Some decisions require investment of resources like political capital, budget allocations, or staff time, with the cost reflecting the potential impact.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Risk Assessment</h3>
              <p>
                Each decision option has associated risks, with higher-risk options potentially yielding greater benefits but with increased chances of negative outcomes.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Stakeholder Analysis</h3>
              <p>
                The system identifies key stakeholders for each decision and predicts how they will respond to different options based on their interests and relationships.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Temporal Weighting</h3>
              <p>
                Effects are weighted differently based on their timing, with immediate impacts, mid-term consequences, and long-term outcomes all contributing to decision valuation.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Opportunity Cost</h3>
              <p>
                The system considers what opportunities might be foreclosed by each decision, adding a strategic layer to decision evaluation beyond direct consequences.
              </p>
            </div>
          </div>

          <div className="border-l-4 border-primary p-4 bg-muted/50 mt-6">
            <h3 className="text-lg font-semibold mb-2">Value Alignment Scoring</h3>
            <p>
              The game tracks how player decisions align with various value systems and ideological positions:
            </p>
            <ul className="list-disc pl-6 mt-2 space-y-1">
              <li>Progressive vs. Conservative approaches</li>
              <li>Collectivist vs. Individualist values</li>
              <li>Authoritarian vs. Democratic governance</li>
              <li>Isolationist vs. Internationalist foreign policy</li>
              <li>Technocratic vs. Populist decision-making</li>
              <li>Traditional vs. Innovative solutions</li>
            </ul>
            <p className="mt-2">
              These alignments influence how different characters and constituencies respond to the player's leadership.
            </p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Metrics Visualization & Feedback</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            Executive Disorder provides players with rich feedback on how their decisions are affecting the game world:
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Real-Time Dashboard</h3>
              <p>
                A comprehensive dashboard displays current values for all major metrics, with visual indicators for trends and critical thresholds.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Immediate Decision Feedback</h3>
              <p>
                After each decision, players receive immediate visual feedback showing how metrics have changed, with explanations for significant shifts.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Trend Analysis</h3>
              <p>
                Players can access trend data showing how metrics have changed over time, helping identify patterns and the cumulative impact of multiple decisions.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Advisor Briefings</h3>
              <p>
                In-game advisors provide regular briefings on the state of different metric categories, highlighting areas of concern or opportunity.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Media Coverage</h3>
              <p>
                In-game media outlets report on significant metric changes, providing narrative context and reflecting public perception of administration performance.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Crisis Triggers</h3>
              <p>
                When metrics reach critical thresholds (either positive or negative), special events or crisis scenarios may trigger, creating dynamic gameplay responses.
              </p>
            </div>
          </div>

          <p className="mt-4">
            This comprehensive metrics and impact system creates a deeply responsive game world that adapts to player decisions in meaningful ways, ensuring that each playthrough of Executive Disorder offers a unique experience shaped by the player's governance choices and priorities.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
