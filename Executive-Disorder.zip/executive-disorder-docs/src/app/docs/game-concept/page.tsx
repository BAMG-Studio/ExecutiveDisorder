import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import Image from "next/image";

export default function GameConceptPage() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">Game Concept & Core Mechanics</h1>
        <p className="text-muted-foreground text-lg">
          A comprehensive overview of Executive Disorder's game concept and fundamental mechanics
        </p>
        <Separator className="my-4" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Game Overview</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            Executive Disorder is a satirical political simulation strategy game where players assume the role of a newly elected President navigating through the challenges of governing a nation. The game combines crisis management, political maneuvering, and social media dynamics to create a unique and engaging gameplay experience.
          </p>
          <div className="relative rounded-md overflow-hidden h-60 my-4">
            <Image
              src="/assets/k69eemwqmw2-image.png"
              alt="Executive Disorder Concept Art"
              fill
              className="object-cover"
            />
          </div>
          <p>
            Set in a fictional modern democratic nation, players must balance multiple competing interests, manage public opinion, and respond to both planned and unexpected crises while maintaining their political capital and working toward policy goals.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Core Game Loop</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            The core gameplay loop of Executive Disorder revolves around these key elements:
          </p>
          <ul className="list-disc pl-6 space-y-2">
            <li>
              <strong>Daily Decision Making:</strong> Each in-game day presents players with a set of decisions via the card system, requiring careful consideration of short and long-term consequences.
            </li>
            <li>
              <strong>Crisis Management:</strong> Unexpected events force players to make quick decisions under pressure, with outcomes affecting multiple game metrics.
            </li>
            <li>
              <strong>Resource Balancing:</strong> Managing various resources including political capital, public opinion, party support, and budget allocations.
            </li>
            <li>
              <strong>Social Media Engagement:</strong> Engaging with the in-game social media ("MemeSpace") to counter negative narratives, promote policy initiatives, and shape public perception.
            </li>
            <li>
              <strong>Strategic Planning:</strong> Working toward long-term policy goals while managing day-to-day governmental operations.
            </li>
          </ul>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Key Mechanics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Card-Based Decision System</h3>
              <p>
                Executive Disorder implements a sophisticated card-based decision system where each card represents a policy decision, political appointment, or response to a situation. Cards have immediate effects on game metrics and may trigger future consequences.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Multi-dimensional Resource Management</h3>
              <p>
                Players must balance multiple resources simultaneously, including approval ratings among different demographic groups, party support, budget allocations across departments, and foreign relations.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Dynamic Crisis Events</h3>
              <p>
                The game features both scripted and procedurally generated crisis events that test the player's ability to respond effectively under pressure, with various narrative and gameplay consequences.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Meme Warfare System</h3>
              <p>
                A unique social media simulation allows players to craft and deploy memes to counter opposition narratives, amplify policy successes, and shape public discourse around key issues.
              </p>
              <div className="relative rounded-md overflow-hidden h-32">
                <Image
                  src="/assets/bgwl6gykffh-image.png"
                  alt="Meme Warfare System"
                  fill
                  className="object-cover"
                />
              </div>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Character Relationship System</h3>
              <p>
                A dynamic relationship system tracks player interactions with key NPCs including cabinet members, opposition leaders, foreign diplomats, and media figures, affecting their loyalty and support.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Consequence Tracking</h3>
              <p>
                The game meticulously tracks player decisions and their consequences, creating a complex web of cause-and-effect relationships that shape the game world over time.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Game World & Setting</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            Executive Disorder is set in a fictional modern democratic nation that draws inspiration from various real-world political systems while maintaining a satirical edge. The game world includes:
          </p>
          <ul className="list-disc pl-6 space-y-2">
            <li>
              <strong>Rich Political Landscape:</strong> Multiple political parties, interest groups, and power centers with their own agendas
            </li>
            <li>
              <strong>Dynamic Media Environment:</strong> Various media outlets with different political leanings that report on player actions
            </li>
            <li>
              <strong>International Relations:</strong> Relationships with foreign nations that require diplomatic management
            </li>
            <li>
              <strong>Domestic Infrastructure:</strong> Various governmental departments and agencies that must be managed effectively
            </li>
            <li>
              <strong>Social Factions:</strong> Different demographic groups with varying interests and concerns
            </li>
          </ul>
          <p>
            The setting allows for both serious political simulation and humorous satirical elements, creating a gameplay experience that is both engaging and thought-provoking.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
