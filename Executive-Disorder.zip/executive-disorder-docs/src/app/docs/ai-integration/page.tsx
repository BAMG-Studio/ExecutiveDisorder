import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import Image from "next/image";

export default function AIIntegrationPage() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">AI Integration & Technical Implementation</h1>
        <p className="text-muted-foreground text-lg">
          Technical details on Executive Disorder's AI systems and implementation architecture
        </p>
        <Separator className="my-4" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>AI Systems Overview</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            Executive Disorder leverages advanced AI systems to create a deeply responsive and dynamic gameplay experience. These AI systems work together to generate emergent narrative possibilities, adapt to player choices, and create a game world that feels alive and reactive.
          </p>
          <div className="relative rounded-md overflow-hidden h-60 my-4">
            <Image
              src="/assets/l2l1bc8g0p7-image.png"
              alt="Executive Disorder AI Architecture"
              fill
              className="object-cover"
            />
          </div>
          <p>
            The game's AI integration spans multiple systems including character behavior, narrative generation, crisis simulation, media dynamics, and political modeling. These systems are designed to work both independently and in concert to create a coherent and challenging gameplay experience.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Core AI Subsystems</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Narrative Engine</h3>
              <p>
                Generates dynamic storylines and events based on player decisions and game state.
              </p>
              <ul className="list-disc pl-6">
                <li>Procedural event generation</li>
                <li>Causal chain modeling</li>
                <li>Narrative coherence algorithms</li>
                <li>Story arc management</li>
                <li>Dramatic tension control</li>
              </ul>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Character Simulation</h3>
              <p>
                Models NPC behaviors, relationships, and reactions to player actions.
              </p>
              <ul className="list-disc pl-6">
                <li>Personality trait modeling</li>
                <li>Relationship dynamics simulation</li>
                <li>Goal-oriented behavior trees</li>
                <li>Memory and learning systems</li>
                <li>Emotional response algorithms</li>
              </ul>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Political Simulation</h3>
              <p>
                Models complex political dynamics including faction behavior, public opinion shifts, and power structures.
              </p>
              <ul className="list-disc pl-6">
                <li>Faction interest modeling</li>
                <li>Coalition formation algorithms</li>
                <li>Power dynamics simulation</li>
                <li>Policy impact prediction</li>
                <li>Approval rating dynamics</li>
              </ul>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Media Simulation</h3>
              <p>
                Simulates media coverage, social media dynamics, and information propagation.
              </p>
              <ul className="list-disc pl-6">
                <li>News cycle simulation</li>
                <li>Content virality modeling</li>
                <li>Media bias representation</li>
                <li>Narrative framing algorithms</li>
                <li>Public attention mechanics</li>
              </ul>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Crisis Generator</h3>
              <p>
                Creates and manages crisis events with appropriate timing, scale, and context sensitivity.
              </p>
              <ul className="list-disc pl-6">
                <li>Risk factor monitoring</li>
                <li>Cascading failure simulation</li>
                <li>Contextual crisis selection</li>
                <li>Escalation path modeling</li>
                <li>Response effectiveness evaluation</li>
              </ul>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Dialogue System</h3>
              <p>
                Generates contextually appropriate dialogue and conversation options with NPCs.
              </p>
              <ul className="list-disc pl-6">
                <li>Context-aware response generation</li>
                <li>Character voice consistency</li>
                <li>Emotional subtext modeling</li>
                <li>Memory-based conversation history</li>
                <li>Dynamic topic selection</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>AI Architecture</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            Executive Disorder implements a sophisticated AI architecture designed for responsiveness, adaptability, and emergent gameplay:
          </p>

          <div className="border p-6 rounded-md space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Layered AI System</h3>
                <p>
                  The game uses a layered AI architecture that separates strategic, tactical, and reactive decision-making across different systems, allowing for appropriate responses at different time scales and complexity levels.
                </p>
              </div>

              <div className="space-y-3">
                <h3 className="text-lg font-semibold">State-Tracking Database</h3>
                <p>
                  A comprehensive state-tracking system maintains detailed information about the game world, character relationships, and decision history, providing context for AI decision-making.
                </p>
              </div>

              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Event-Driven Architecture</h3>
                <p>
                  AI systems communicate through an event system that allows different components to react to changes in the game state, creating complex emergent behaviors without tight coupling.
                </p>
              </div>

              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Scenario Graph System</h3>
                <p>
                  A specialized graph-based representation of potential narrative paths allows the AI to plan coherent story arcs while adapting to player choices, maintaining narrative consistency.
                </p>
              </div>
            </div>

            <div className="relative rounded-md overflow-hidden h-60 mt-6">
              <Image
                src="/assets/l2l1bc8g0p7-image.png"
                alt="AI Architecture Diagram"
                fill
                className="object-contain"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>AI Models & Algorithms</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            Executive Disorder employs several key AI models and algorithms:
          </p>

          <ul className="list-disc pl-6 space-y-3">
            <li>
              <strong>Decision Trees:</strong> Used for tactical decision-making in character AI, with dynamic tree construction based on character traits and current context.
            </li>
            <li>
              <strong>Behavior Trees:</strong> Implement complex character behaviors with fallbacks and priorities, allowing characters to pursue goals while responding to changing circumstances.
            </li>
            <li>
              <strong>Reinforcement Learning:</strong> Applied to media AI systems that learn effective narrative framing techniques based on public response, creating increasingly sophisticated opposition.
            </li>
            <li>
              <strong>Agent-Based Modeling:</strong> Powers the political simulation system where multiple agents with individual goals interact to create emergent political dynamics.
            </li>
            <li>
              <strong>Neural Language Models:</strong> Drive the dialogue system, generating contextually appropriate conversations with tonal and personality consistency.
            </li>
            <li>
              <strong>Monte Carlo Simulations:</strong> Used to predict potential outcomes of player decisions, informing NPC reactions and anticipatory behaviors.
            </li>
            <li>
              <strong>Pattern Recognition:</strong> Applied to player decision history to identify governance patterns and adapt the game accordingly.
            </li>
          </ul>

          <div className="border-l-4 border-primary p-4 bg-muted/50 mt-4">
            <h3 className="text-lg font-semibold mb-2">Dynamic Difficulty Adjustment</h3>
            <p>
              The game implements a sophisticated dynamic difficulty system that:
            </p>
            <ul className="list-disc pl-6 mt-2 space-y-1">
              <li>Monitors player performance across multiple metrics</li>
              <li>Identifies player strengths and weaknesses</li>
              <li>Adjusts challenge levels in different gameplay domains</li>
              <li>Creates personalized challenge curves</li>
              <li>Maintains appropriate tension without frustration</li>
              <li>Adapts to player learning and skill development</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Technical Implementation</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">
            The game's technical implementation focuses on creating a responsive, dynamic, and scalable system:
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Core Engine</h3>
              <p>
                Built on Unreal Engine with custom extensions for political simulation, narrative generation, and character AI. The engine provides high-performance rendering while custom systems handle game-specific mechanics.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Data Management</h3>
              <p>
                Uses a hybrid data system with a relational database for entity relationships and document storage for complex state snapshots. This supports both structured queries and flexible state representation.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">AI Processing Pipeline</h3>
              <p>
                Implements a multi-stage AI processing pipeline with preprocessing, contextualization, decision-making, and post-processing stages. This allows for efficient resource allocation and priority-based scheduling.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Procedural Content Generation</h3>
              <p>
                Uses templated content generation with parameter variation to create diverse scenarios, character interactions, and media content while maintaining quality and narrative consistency.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Asynchronous Processing</h3>
              <p>
                Heavy AI calculations run asynchronously on separate threads with a caching system to ensure responsive gameplay even during complex simulations and predictions.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Memory Management</h3>
              <p>
                Implements smart memory management with importance-based retention and compression for historical data, allowing long-term persistence of meaningful events without excessive memory usage.
              </p>
            </div>
          </div>

          <div className="border p-4 rounded-md mt-6">
            <h3 className="text-lg font-semibold mb-2">Performance Optimization</h3>
            <p className="mb-2">
              Several optimization strategies ensure the complex AI systems run efficiently:
            </p>
            <ul className="list-disc pl-6 grid grid-cols-1 md:grid-cols-2 gap-2">
              <li>Multi-level AI LOD (Level of Detail) system</li>
              <li>Importance-based processing prioritization</li>
              <li>Dynamic resource allocation</li>
              <li>Predictive precalculation of likely scenarios</li>
              <li>Batch processing for related AI decisions</li>
              <li>Result caching with invalidation triggers</li>
              <li>Optimized pathfinding in decision spaces</li>
              <li>Simplified models for distant entities</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Content Generation Systems</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            Executive Disorder uses AI-driven content generation systems to create diverse gameplay experiences:
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Scenario Generator</h3>
              <p>
                Creates diverse crisis scenarios and political situations by combining elements from a large possibility space with contextual constraints.
              </p>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Character Generator</h3>
              <p>
                Procedurally creates NPCs with coherent trait combinations, backstories, and relationship networks that fit the current game world.
              </p>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Meme Factory</h3>
              <p>
                Generates visually and thematically appropriate meme content for both player use and opposition social media campaigns.
              </p>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Media Content Generator</h3>
              <p>
                Creates news headlines, articles, and media segments that report on game events with appropriate bias and framing.
              </p>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Policy Proposal Engine</h3>
              <p>
                Generates policy proposals with coherent effects, costs, and stakeholder impacts based on current game issues and political climate.
              </p>
            </div>

            <div className="space-y-3 border p-4 rounded-md">
              <h3 className="text-lg font-semibold">Dialogue Generator</h3>
              <p>
                Creates contextually appropriate dialogue options and NPC responses that reflect character personalities and relationship status.
              </p>
            </div>
          </div>

          <p className="mt-4">
            These AI systems work together to create a rich, dynamic, and responsive gameplay experience that adapts to player choices while maintaining narrative coherence and strategic depth. The technical implementation prioritizes performance, scalability, and emergent complexity to deliver a uniquely engaging political simulation.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
