import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { NavigationMenu, NavigationMenuContent, NavigationMenuItem, NavigationMenuLink, NavigationMenuList, NavigationMenuTrigger } from "@/components/ui/navigation-menu";
import { Separator } from "@/components/ui/separator";
import Image from "next/image";

export default function Home() {
  const sections = [
    {
      id: "game-concept",
      title: "Game Concept & Core Mechanics",
      description: "Overview of the game's concept and core gameplay mechanics"
    },
    {
      id: "character-profiles",
      title: "Character Profiles & Strategies",
      description: "Detailed profiles of characters and strategic approaches"
    },
    {
      id: "card-system",
      title: "Card System & Decision Mechanics",
      description: "The card system design and decision-making mechanics"
    },
    {
      id: "gameplay-metrics",
      title: "Gameplay Metrics & Decision Impact System",
      description: "How player decisions impact game metrics and outcomes"
    },
    {
      id: "crisis-scenes",
      title: "Crisis Scenes & Meme Warfare",
      description: "Crisis event design and social media meme mechanics"
    },
    {
      id: "ai-integration",
      title: "AI Integration & Technical Implementation",
      description: "Technical details on AI integration and implementation"
    },
    {
      id: "art-sound-ui",
      title: "Art, Sound & UI/UX Design",
      description: "Visual, audio, and interface design elements"
    },
    {
      id: "development-roadmap",
      title: "Development Roadmap & Timeline",
      description: "Project timeline, milestones, and development plan"
    }
  ];

  return (
    <main className="min-h-screen">
      <div className="bg-primary py-8">
        <div className="container">
          <h1 className="text-4xl md:text-6xl font-bold text-primary-foreground mb-4">
            Executive Disorder
          </h1>
          <p className="text-xl text-primary-foreground opacity-90">
            Comprehensive Game Design Documentation
          </p>
        </div>
      </div>

      <div className="container py-8">
        <div className="flex flex-col md:flex-row gap-8">
          <div className="md:w-1/4">
            <div className="sticky top-8">
              <NavigationMenu className="flex flex-col w-full">
                <NavigationMenuList className="flex flex-col w-full space-y-1">
                  {sections.map((section) => (
                    <NavigationMenuItem key={section.id} className="w-full">
                      <Link href={`/docs/${section.id}`} legacyBehavior passHref>
                        <NavigationMenuLink className="w-full block px-4 py-2 hover:bg-accent rounded-md">
                          {section.title}
                        </NavigationMenuLink>
                      </Link>
                    </NavigationMenuItem>
                  ))}
                </NavigationMenuList>
              </NavigationMenu>
            </div>
          </div>

          <div className="md:w-3/4">
            <div className="mb-8">
              <Card className="mb-8 bg-muted/50">
                <CardHeader>
                  <CardTitle>About Executive Disorder</CardTitle>
                  <CardDescription>
                    A political simulation strategy game combining crisis management with social media dynamics
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="mb-4">
                    Executive Disorder is a satirical political strategy game where players take on the role of a newly elected President navigating through various crises, political opponents, and social media challenges. The game combines deep strategic decision-making with real-time crisis management and meme warfare elements.
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-6">
                    <div className="aspect-video relative rounded-md overflow-hidden">
                      <Image
                        src="/assets/k69eemwqmw2-image.png"
                        alt="Executive Disorder Game Concept"
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="aspect-video relative rounded-md overflow-hidden">
                      <Image
                        src="/assets/l2l1bc8g0p7-image.png"
                        alt="Executive Disorder Gameplay"
                        fill
                        className="object-cover"
                      />
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button asChild>
                    <Link href="/docs/game-concept">
                      Explore the Documentation
                    </Link>
                  </Button>
                </CardFooter>
              </Card>

              <h2 className="text-2xl font-bold mb-4">Documentation Sections</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {sections.map((section) => (
                  <Card key={section.id} className="hover:bg-accent/10 transition-colors">
                    <CardHeader>
                      <CardTitle className="text-xl">{section.title}</CardTitle>
                      <CardDescription>{section.description}</CardDescription>
                    </CardHeader>
                    <CardFooter>
                      <Button variant="outline" asChild>
                        <Link href={`/docs/${section.id}`}>
                          View Details
                        </Link>
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
