# Executive Disorder - UI/UX Design System

## Color Palette

### Primary Colors
- **Authority Blue:** #1a1d28 - Main backgrounds, official elements
- **Crisis Red:** #8c6470 - Alerts, warnings, critical situations
- **Presidential Gold:** #c9b062 - Achievements, important elements, prestige indicators

### Secondary Colors
- **Progress Teal:** #6ecbd8 - Technology, progress metrics, innovation
- **Neutral Beige:** #d3c8b6 - Background elements, neutral information
- **Intrigue Purple:** #271835 - Secret information, intelligence matters

### Accent Colors
- **Alert Red:** #e63946 - Critical warnings, imminent threats
- **Success Green:** #2a9d8f - Positive outcomes, approvals
- **Opposition Orange:** #f4a261 - Opposition activities, challenges
- **Diplomatic Blue:** #457b9d - Foreign relations, diplomacy

### UI State Colors
- **Inactive:** #6c757d - Disabled elements
- **Hover:** #f8f9fa - Highlight on hover
- **Selected:** #212529 - Selected elements

## Typography

### Fonts
- **Headers:** 'Montserrat Bold' - All major headings and announcements
- **Body Text:** 'Merriweather' - All standard text and descriptions
- **Data Elements:** 'Roboto Mono' - Statistics, numbers, code-like information

### Text Sizes
- **Large Headings:** 24px
- **Medium Headings:** 20px
- **Small Headings:** 16px
- **Body Text:** 14px
- **Small Text:** 12px
- **Data Elements:** 14px

## UI Components

### Cards
Cards serve as the primary containers for information and decisions. Inspired by government documents, each card should feature:
- Light drop shadow
- Subtle border
- Official-looking header with seal or emblem
- Clear title
- Body content with adequate spacing
- Action buttons at the bottom

### Buttons
- **Primary Action:** Solid background (using appropriate contextual color)
- **Secondary Action:** Outlined style with color matching the action type
- **Tertiary Action:** Text-only with minimal styling

### Icons
A consistent icon set should be used throughout the interface, with variations for:
- Resource types (budget, political capital, military strength)
- Alert levels (warning, critical, informational)
- Department identifiers (defense, economy, foreign affairs)
- Action types (approve, reject, investigate)

### Progress Indicators
Circular progress indicators should be used for:
- Approval ratings
- Project completion
- Crisis containment
- Resource depletion

Linear progress bars should be used for:
- Time-based activities
- Sequential processes
- Comparative metrics

## Layout Guidelines

### Grid System
- Base grid: 8px
- Layout grid: 24px
- Margins: 16px (desktop), 8px (mobile)
- Gutters: 24px (desktop), 16px (mobile)

### Component Spacing
- Card padding: 16px
- Section spacing: 24px
- Button padding: 8px 16px
- Input field padding: 8px

### Responsive Breakpoints
- Mobile: 0-767px
- Tablet: 768-1023px
- Desktop: 1024px+

## Animation Guidelines

### Transitions
- Standard transition: 0.2s ease-in-out
- Emphasis transition: 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
- Alert transition: 0.15s ease

### Micro-interactions
- Button press: Slight scale down (0.98)
- Card hover: Subtle lift (elevation increase)
- Icon activation: Color shift + small bounce

### Character Animations
- Idle state: Subtle breathing/movement
- Speaking: Facial animation + gesture variations
- Reaction: Expressive changes based on context
- Entrance/Exit: Slide with fade

## Interface Sections

### Presidential Dashboard
The central hub of the game, featuring:
- Current approval rating (circular indicator)
- Cabinet satisfaction levels (horizontal bars)
- Resource meters (numerical with trend icons)
- Upcoming events timeline
- Active crisis indicators
- Quick action buttons

### Decision Interface
Decision points should feature:
- Character portrait with appropriate emotion
- Detailed scenario description
- 2-4 response options with preview icons
- Timer for urgent decisions
- Resource impact indicators
- Department/advisor recommendation badge

### National Map
Interactive visualization showing:
- Regional approval levels (color gradients)
- Crisis hotspots (animated indicators)
- Resource distribution (symbolic icons)
- Opposition strongholds (pattern overlays)
- International relations (border styling)

### Relationship Network
Character relationship visualization:
- Node-based character network
- Relationship strength indicators (line thickness)
- Relationship type (line color)
- Character influence (node size)
- Faction groupings (node clusters)

### Media Monitor
Social media simulation panel:
- Trending topics list
- Public opinion meters
- Recent headline carousel
- Meme effectiveness tracking
- Message crafting interface

## Iconography System

### Resource Icons
- **Budget:** Stylized currency symbol
- **Political Capital:** Star in circle
- **Public Approval:** Thumbs up
- **Military Strength:** Shield
- **Foreign Relations:** Globe
- **Intelligence:** Eye or magnifying glass

### Status Icons
- **Improving:** Upward arrow
- **Declining:** Downward arrow
- **Stable:** Horizontal line
- **Volatile:** Zigzag line
- **Blocked:** X symbol
- **Accelerating:** Double arrow

### Action Icons
- **Approve:** Checkmark
- **Reject:** X
- **Investigate:** Magnifying glass
- **Delegate:** Arrow pointing right
- **Postpone:** Clock
- **Escalate:** Exclamation mark

## Sound Design

### UI Sounds
- **Button Click:** Soft mechanical click
- **Card Appearance:** Paper shuffle
- **Error:** Muted buzz
- **Success:** Positive chime
- **Navigation:** Soft tap
- **Selection:** Gentle click

### Notification Sounds
- **Standard Alert:** Single notification tone
- **Urgent Alert:** Double tone with urgency
- **Critical Crisis:** Alarm-like multi-tone
- **Positive News:** Rising pleasant chime
- **Negative News:** Descending tone

### Ambient Sound
- **Presidential Office:** Subtle office ambience
- **Crisis Room:** Tense, low hum with occasional beeps
- **Public Event:** Crowd murmurs
- **Media Briefing:** Camera shutters and murmuring

## Implementation Guidelines

### Component Hierarchy
1. App container
2. View container
3. Section container
4. Card/Panel container
5. Content elements
6. Interactive elements

### State Management
Track UI states for:
- Hover
- Selected
- Active
- Disabled
- Error
- Loading

### Accessibility
- Ensure color contrast meets WCAG AA standards
- Provide text alternatives for all icons
- Ensure all interactive elements are keyboard accessible
- Design for screen reader compatibility
- Include options for text resizing

### Performance Considerations
- Optimize animation for low-end devices
- Implement progressive loading for complex views
- Use asset compression for images
- Limit the number of simultaneous animations
- Consider device capabilities for effects

## Character Design Guidelines

### Cabinet Members
Each cabinet member should have:
- Distinct silhouette
- Characteristic posture
- Signature color accent
- Consistent clothing style
- Range of emotional expressions (minimum 6)

### Foreign Leaders
Foreign leader designs should include:
- Cultural visual elements
- Distinctive formal attire
- Characteristic accessory or feature
- Range of diplomatic expressions
- National color themes

### Opposition Figures
Opposition characters should feature:
- Contrasting color palette
- Expressive gestures
- Visual indicators of political leaning
- Distinct clothing style
- Dynamic poses

## Adaptive Elements

### Dynamic Time of Day
Interface should subtly reflect the time of day:
- Morning: Brighter, more energetic colors
- Afternoon: Standard palette
- Evening: Warmer, slightly dimmed
- Night: Darker backgrounds, higher contrast

### Situational Adaptations
During crisis events:
- Color shift toward alert colors
- Increased animation urgency
- More prominent alerts
- Simplified non-essential elements

## Loading and Transition Screens

### Loading Indicators
- Primary loading: Presidential seal rotating
- Secondary loading: Simple progress bar
- Contextual loading: Department-specific icon

### Transition Elements
- Between major sections: Slide transitions
- For new information: Fade in
- For alerts: Quick fade with attention animation
- For completed actions: Satisfaction animation (checkmark)

## References & Inspiration
- Mobile Subculture Game UI/UX - Character-centric interface with information layering
- M_SUBCULTURE-STYLE_FPS-GAMEUIUX - Resource visualization and status indicators
- Failed State - Satirical style and crisis management presentation

## Version Control
Document version: 1.0
Last updated: [Current Date]
